<!-- Emergrncy Number Area Start Here -->
<div class="emergrncy-number-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                <div class="emergrncy-img-holder"></div>
            </div>
            <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                <div class="emergrncy-content-holder">
                    <div class="emergrncy-content-holder-inner">
                        <h3><?php echo $Phrase[0];?> ,Call: <a href="<?php echo $PhoneRef;?>" class="text-white"><?php echo $Phone;?></a></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Emergrncy Number Area End Here -->