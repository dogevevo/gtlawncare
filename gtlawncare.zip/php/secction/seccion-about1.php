<div class="about-us-page1-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="about-us-goal">
                    <h2 class="title-bar50">Bienvenidos a<span class="color"> <?php echo $Company;?></span></h2>
                    <p><?php echo $Home[1];?></p>
                    <p><?php echo $Home[2];?></p>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">              
                <img src="img/about/1.jpg" alt="Obten tu mejor opcion en cafe!" loading="lazy">
            </div>
        </div>
    </div>
</div>