<!--* Partner*-->
    <section id="mt_partner">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <!-- section title -->
                    <div class="section_heading">
                        <h2 class="section_title">
                            <span><?php echo $Partner[0]?></span>
                        </h2>
                        
                    </div>
                </div>
            </div>

            <div class="row slider-partner">
                <div class="col-sm-2">
                    <a href="https://www.angi.com/"><img src="img/partner/Angi.png" alt="partner"></a>
                </div>
                <div class="col-sm-2">
                    <a href="https://www.yelp.com/"><img src="img/partner/yelp.png" alt="partner"></a>
                </div>
                <div class="col-sm-2">
                    <a href="https://www.thumbtack.com/"><img src="img/partner/thum.png" alt="partner"></a>
                </div>
                <div class="col-sm-2">
                    <a href=""><img src="img/partner/3.png" alt="partner"></a>
                </div>
                <div class="col-sm-2">
                    <a href="https://www.manta.com/"><img src="img/partner/manta.png" alt="partner"></a>
                </div>
                <div class="col-sm-2">
                    <a href="https://craigslist.org/"><img src="img/partner/Crai.png" alt="partner"></a>
                </div>
                <div class="col-sm-2">
                    <a href="https://espanol.yahoo.com/?p=us"><img src="img/partner/Yah.png" alt="partner"></a>
                </div>
            </div>

        </div>
    </section>
    <!--* End partner*-->
    <!--* End partner*-->