   <!--* Services*-->


   <section id="mt_services" class="wow slideInLeft">
        <div class="container">
                
            <div class="services-inner">
                <div class="row">
                <div class="col-md-4 col-sm-12">
                    <div class="box text-center">
                        <div class="box-content">
                            <div class="icon mar-bottom-20"><i class="fa fa-hand-rock-o"></i></div>
                            <h3><a href="service.php">Large Number of Services Provided</a></h3>
                            <p class="mar-bottom-20">Excepteur sint occaecat cupi datat non proi dent, sunt in culpa qui off icia..</p>
                            <a href="service.php" class="mt_btn_yellow">View Services</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="box text-center">
                        <div class="box-content">
                            <div class="icon mar-bottom-20"><i class="fa fa-users"></i></div>
                            <h3><a href="service.php">10+ Years ofProfessional Experience</a></h3>
                            <p class="mar-bottom-20">Excepteur sint occaecat cupi datat non proi dent, sunt in culpa qui off icia..</p>
                            <a href="service.php" class="mt_btn_yellow">View Services</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="box text-center">
                        <div class="box-content">
                            <div class="icon mar-bottom-20"><i class="fa fa-graduation-cap"></i></div>
                            <h3><a href="service.php">A Large Numberof Grateful Customers</a></h3>
                            <p class="mar-bottom-20">Excepteur sint occaecat cupi datat non proi dent, sunt in culpa qui off icia..</p>
                            <a href="service.php" class="mt_btn_yellow">View Services</a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </section>
    <!--* End Services*-->