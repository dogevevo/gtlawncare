<!--*About*-->
<section id="mt_about">
        <div class="container">
   
            <div class="about_inner">
                <div class="row">

                    <div class="col-md-6 col-sm-12">
                        <div class="about-content">
                            <span class="mar-bottom-15">About Company</span>
                            <h2 class="mar-bottom-30"> <?php echo $About[0]  ?> </h2>
                            <p class="mar-bottom-40"> <?php echo $About[1]  ?> </p>
                            <a href="services.php" class="btn mt_btn_yellow">Our Services</a>
                        </div>
                    </div>

                    <div class="col-md-6 col-sm-12 wow slideInDown">
                        <div class="about-img">
                            <img src="img/project/2.jpg">
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--*EndAbout*-->