<!-- Mobile Menu Area Start -->
<div class="mobile-menu-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mobile-menu">                    
                    <nav id="dropdown">
                       <ul>
                            <li> <a href="index.php">Inicio</a> </li>
                            <li> <a href="about.php">Acerca de nosotros</a> </li>
                            <li> <a href="services.php">Servicios</a> </li>
                            <li> <a href="gallery.php">Galeria</a> </li>
                            <li><a href="contact.php">Contactanos</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div><br><br>
<!-- Mobile Menu Area End -->