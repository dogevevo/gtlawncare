<section id="mt_get_started">
    <div class="container">
        <div class="watch_inner">
            <img src="img/show.png" alt="">
            <div class="watch_content">
                <h3 class="white"><?php echo $Video_Text[0]  ?></h3>
                <h2 class="white"><?php echo $Video_Text[1]  ?></h2>
                <p><?php echo $Video_Text[2]  ?></p>
                <a href="gallery.php" class="btn mt_btn_yellow mar-top-30">View Work Process</a>
            </div>
            <div class="pulses">
            </div>
        </div>
    </div>
</section>