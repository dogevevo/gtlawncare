<!--* Services*-->
<br><br><br><br>
<br>
<section id="mt_services" class="wow slideInLeft">
        <div class="container">

            <div class="row">
                <div class="col-xs-12">
                    <!-- section title -->
                    <div class="section_heading text-center">
                        <h4 class="text-uppercase">Our Best Services</h4>
                        <h2 class="section_title">
                            <span><?php echo $Services_Parraf[0] ?></span>
                        </h2>
                        <p class="heading_txt mar-top-30"></p>
                    </div>
                </div>
            </div>
                  
            <div class="row slider-services1">
                <div class="col-md-4 col-sm-6 col-xs-6">
                    <div class="box text-center">
                        <img src="img/blog-listing/s1.jpg" alt="services-1">
                        <div class="box-content">
                            <h3><a href="services.php"><?php echo $SN[0] ?></a></h3>
                            <p><?php echo $SD[0] ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-6">
                    <div class="box text-center">
                        <img src="img/blog-listing/2.jpg" alt="services-2">
                        <div class="box-content">
                            <h3><a href="services.php"><?php echo $SN[1] ?></a></h3>
                            <p><?php echo $SD[1] ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-6">
                    <div class="box text-center">
                        <img src="img/blog-listing/3.jpg" alt="services-3">
                        <div class="box-content">
                            <h3><a href="services.php"><?php echo $SN[2] ?></a></h3>
                            <p><?php echo $SD[2] ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-6">
                    <div class="box text-center">
                        <img src="img/blog-listing/4.jpg" alt="services-4">
                        <div class="box-content">
                            <h3><a href="services.php"><?php echo $SN[3] ?></a></h3>
                            <p><?php echo $SD[3] ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-6">
                    <div class="box text-center">
                        <img src="img/blog-listing/5.jpg" alt="services-5">
                        <div class="box-content">
                            <h3><a href="services.php"><?php echo $SN[4] ?></a></h3>
                            <p><?php echo $SD[4] ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-6">
                    <div class="box text-center">
                        <img src="img/blog-listing/6.jpg" alt="services-6">
                        <div class="box-content">                              
                            <h3><a href="services.php"><?php echo $SN[5] ?></a></h3>
                            <p><?php echo $SD[5] ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <p class="mar-top-30 text-center"><strong> <u><a href="services.php">Explore all services</a></u></strong></p>
        </div>
    </section>
    <!--* End Services*-->