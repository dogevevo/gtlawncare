<?php include('php/secction/header.php') ?>
<div class="inner-page-banner-area">
    <div class="container">
        <div class="pagination-area">
            <h2>Muchas Gracias</h2>
            <ul>
                <li><a href="index.php">Inicio</a> /</li>
                <li>Muchas Gracias</li>
            </ul>
        </div>
    </div>
</div>

<div class="about-us-page1-area">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-9 col-md-offset-1">
                <div class="about-us-goal">
                    <h2 class="text-black">Gracias por <span class="color">enviarnos tu </span> solicitud. <i class="color fa fa-envelope-o"></i></h2>
                    <h4 class="text-black">Tu mensaje sera contestado en breve.</h4>
                    <a class="btn-read-more-h-b" href="index.php">Volver al Inicio</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('php/secction/footer.php') ?>
