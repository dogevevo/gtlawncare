<?php include('php/secction/header.php') ?>
<?php include('php/secction/slider.php') ?>
<?php include('php/secction/seccion-about0.php') ?>
<!-- <--?php include('php/secction/seccion-about1.php') ?---> 
<?php include('php/secction/seccion-service2.php') ?>
<?php include('php/secction/ChooseUs.php') ?>
<?php include('php/secction/seccion-gallery.php') ?>
<?php include('php/secction/seccion-video.php') ?>
<br><br><br><br><br>
<?php include('php/secction/seccion-partner.php') ?>
<?php include('php/secction/seccion-bg2.php') ?>
<?php include('php/secction/footer.php') ?> 